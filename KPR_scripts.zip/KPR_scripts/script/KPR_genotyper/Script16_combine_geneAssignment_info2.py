#!/usr/bin/python

import sys
from os import path

def read_count():
        with open('Script2_norm_sequences','r') as f:
                norm = f.read()
        with open('Script2_DLA64_sequences','r') as f:
                dla64 = f.read()
        with open('Script2_50X_sequences','r') as f:
                x50 = f.read()
        if '>' in norm:
                norm = len(norm.split('>')) - 1
        else:
                norm = 0
        if '>' in dla64:
                dla64 = len(dla64.split('>')) - 1
        else:
                dla64 = 0
        if '>' in x50:
                x50 = len(x50.split('>')) - 1
        else:
                x50 = 0
        total = norm + x50 + dla64
        if total == 0:
                total == 1
        normPerc = float(norm) / total
        x50Perc = float(x50) / total
        dla64Perc = float(dla64) / total
        return normPerc,x50Perc,dla64Perc

def file_count(lst):
        normPerc,x50Perc,dla64Perc = 0.0,0.0,0.0
        for i in range(len(lst)):
                info = lst[i].split('\t')
                contig = info[1]
                perc = float(info[2])
                prot = info[5]
                if 'DLA64' in contig:
                        dla64Perc += perc
                elif len(prot) >= 183:
                        x50Perc += perc
                else:
                        normPerc += perc
        return normPerc,x50Perc,dla64Perc
        

if __name__ == '__main__':
	file0 = sys.argv[1]
	geneAssignment = sys.argv[2]
	with open(file0,'r') as f:
		file = f.read()
	lst = file.split('\n')[:-1]
	allele_dic = {}
	if path.isfile(geneAssignment):
		with open(geneAssignment,'r') as f:
			geneAssignment = f.read()
		geneAssignment = geneAssignment.split('\n')[:-1]
		for i in range(len(geneAssignment)):
			allele = geneAssignment[i].split('\t')[0]
			gene = geneAssignment[i].split('\t')[1]
			allele_dic[allele] = gene
	out = open(file0.split('.')[0] + '_withGeneAssignment.txt','w')
        # read number
        normPerc,x50Perc,dla64Perc = read_count()
	normPercGeno,x50PercGeno,dla64PercGeno = file_count(lst)
        # adjust total
        totalPerc = 0.0
        for i in range(len(lst)):
                perc = float(lst[i].split('\t')[2])
                totalPerc += perc
        if (totalPerc == 0.0) and (len(lst) > 0):
                indPerc = 1.0 / len(lst)
        else:
                indPerc = 0.0
        for i in range(len(lst)):
		info = lst[i].split('\t')
		alleleName = info[1]
                perc = float(info[2])
                if totalPerc == 0.0:
                        perc = indPerc
		allele = info[3]
		gp = info[4]
		seq = info[5]
		if alleleName in allele_dic.keys():
			gene = allele_dic[alleleName]
		elif allele != '':
			gene = allele.split('*')[0]
		elif gp != '':
			gene = gp.split('*')[0]
		else:
			gene = ''
		if ('50X' not in alleleName) and ('Norm' not in alleleName):
			if len(seq) > 182:
				tag = '50X'
			else:
				tag = 'Norm'
		alleleName = tag + alleleName
                # adjust perc
                if 'DLA64' in alleleName:
                        if dla64PercGeno != 0:
                                perc_adj = perc * dla64Perc / dla64PercGeno
                        else:
                                perc_adj = perc
                elif len(seq) >= 183:
                        if x50PercGeno != 0:
                                perc_adj = perc * x50Perc / x50PercGeno
                        else:
                                perc_adj = perc
                else:
                        if normPercGeno != 0:
                                perc_adj = perc * normPerc / normPercGeno
                        else:
                                perc_adj = perc
		string = info[0] + '\t' + alleleName + '\t' + str(perc_adj) + '\t' + '\t'.join(info[3:5]) + '\t' + gene + '\t' + '\t'.join(info[5:]) + '\n'
		out.write(string)
	out.close()
